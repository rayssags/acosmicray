# Processos Radiativos

$\large\textit{Professor: Wagner Marcolino | Observatório do Valongo/UFRJ | 2020.1}$

- $\Large Bibliografia$

    ![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled.png)

    [**Radiative processes in astrophysics
    George B Rybicki; Alan P Lightman**](https://www.libgen.is/book/index.php?md5=3BB68FCCF6B3E9FCD4393CF7D355963C)

    ![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%201.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%201.png)

    [**Stellar Atmospheres
    Dimitri Mihalas**](http://www.libgen.is/book/index.php?md5=007D0BDF84BEA04D39EB8C40B186A40D)

    ![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%202.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%202.png)

    [**Classical electrodynamics
    Julian Schwinger, Lester L. Deraad Jr., Kimball A. Milton, Wu-yang Tsai, Joyce Norton**](http://www.libgen.is/book/index.php?md5=53510F5EF87A5AF7D7906AD0CCBAB745)

- $\Large Listas$

    [Lista 1](https://www.notion.so/Lista-1-2a0d9241369b4c92862aae3b690ed514)

    [Lista 2](https://www.notion.so/Lista-2-4d56bce54019435ba1c8b97152d6a927)

    [Lista 3](https://www.notion.so/Lista-3-31409e34bb4f4bddb42f35513ee2aead)

    [Lista 4](https://www.notion.so/Lista-4-ce33c9fac71346a489768d43177dee0d)

- $\Large \textit{Sumário das anotações}$

---

# ✨ **Fundamentos de transporte radiativo**

Em astrofísica, a radiação é a maior fonte — quando não a única — de informação que temos de objetos celestes. Algumas exceções são:

- Meteoritos, material lunar, asteroides;
- Ondas gravitacionais;
- Neutrinos;
- Raios cósmicos

Portanto, podemos dizer que detectar e interpretar corretamente a radiação de objetos astrofísicos é crucial para entendê-los. Primeiramente, vamos tratar a radiação e sua interação com a matéria com o formalismo macroscópico da **teoria de transporte radiativo**.

## Intensidade específica

Definida como  $I_\nu (\vec{r}, \hat{n}, t)$: intensidade da radiação na frequência $\nu$ no ponto $\vec{r}$ que vai na direção $\hat{n}$ no instante t. Essa intensidade é específica com relação à direção.

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/g4236.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/g4236.png)

Também podemos escrever como

- $I_\nu(x,y,z,\hat{n},t)$
- $I_\nu(r,\theta,\phi,\Theta,\Phi,t)$
- $I_\nu(z,\theta,t)$, no caso p-p

$I_\nu$ caracteriza completamente o campo de radiação, de forma a ser capaz prever a radiação que chega na Terra. Isso permite criar um modelo preditivo de espectros observacionais. 

$I_\nu$ é escalar com unidades de
$[I_\nu] = \dfrac{erg}{m²\, Hz\, s\, ster}$

$\begin{aligned} dE &= I_\nu\underbrace{\hat{n}\cdot d\hat{s}}_{\substack{\text{depende da}\\\text{orientação}}}\,d\omega\,d\nu\,dt\\
&=I_\nu\,\hat{n}\,ds\,\cos{\theta}\,d\omega\,d\nu\,dt
\end{aligned}$

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/path14905.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/path14905.png)

A intensidade pode ser transformada em número de fótons apenas dividindo o termo de energia por $h\nu$

$$⁍$$

### Caso plano-paralelo

Nessa aproximação há simetria azimutal e pode ser usada no caso de estrelas tipo solar pois $d_{atm} \lll R_\star$ e até mesmo na atmosfera de exoplanetas. No caso de estrelas como gigantes vermelhas, esse critério não é respeitado e a geometria esférica da atmosfera deve ser considerada.

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/g59796.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/g59796.png)

## Intensidade média

Definimos $J_\nu(\vec{r}, t)$ como a média angular da intensidade específica

$$J_\nu(\vec{r},t) \equiv  \oint \dfrac{I_\nu (\vec{r}, \hat{n},t)}{\oint d\omega} d\omega$$

- Mas $\oint d\omega = 4\pi$, portanto

    Lembrete sobre ângulo sólido 😆

    ![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/g46450.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/g46450.png)

    $\begin{cases}ds = dl_\phi\,dl_\theta\\
    dl_\theta = r\,d\theta\\
    dl_\phi = r\sin\theta\,d\phi\end{cases}$

    $ds = r^2\,sin\theta\,d\theta\,d\phi$

    $d\omega \coloneqq \dfrac{ds}{r^2} = \sin\theta\,d\theta\,d\phi$

    $\oint d\omega = \int\limits_{0}^{\pi} \int\limits_{0}^{2\pi} \sin\theta\,d\theta\,d\phi = 4\pi$

$$J_\nu(\vec{r},t) =  \dfrac{1}{4\pi} \oint I_\nu (\vec{r}, \hat{n},t) d\omega$$

Se o campo é isotrópico, a intensidade é a mesma em todas as direções e a dependência com $\hat{n}$ desaparece.

$$\begin{aligned}

J_\nu(\vec{r},t) & = \dfrac{1}{4\pi} \int I_\nu(\vec{r},\hat{n},t) d\omega
\\
& = I_\nu(\vec{r},t) \cancel{\oint \dfrac{d\omega}{4\pi}}
\\
& = I_\nu(\vec{r},t)
\end{aligned}$$

NB: em um corpo negro, $I_\nu = B_\nu(T)$ e temos que $J_\nu = I_\nu$. Portanto, em corpos em equilíbrio termodinâmico, $J_\nu \to B_\nu$.

### Caso plano-paralelo

$$\begin{aligned}
J_\nu(\vec{r},t) &= \dfrac{1}{4\pi} \int I_\nu(\vec{r},\hat{n},t) d\omega
\\
&= \dfrac{1}{4\pi} \int\int I_\nu(z,\theta,t)\,\overbrace{\sin\theta\,d\theta\,d\phi}^{d\omega}\\
&= \dfrac{1}{2} \int I_\nu(z,\theta,t)\,\sin\theta\,d\theta\\
&= \dfrac{1}{2} \int\limits_{-1}^{1}I_\nu(z,\mu,t)\,d\mu\\
\end{aligned}$$

NB:

- $z$ é profundidade
- Pela simetria azimutal, podemos integrar $d\phi$ primeiro
- Usamos que
$\mu = \cos\theta$ e
$d\mu = -\sin\theta$

## Densidade de energia radiante

Seja

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/path3550.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/path3550.png)

$ds\parallel\hat{n} \implies d\vec{s}\cdot\hat{n} = 1$

A energia que entra no cilindro pode ser escrita como

$\begin{aligned}
dE &= I_\nu\,\hat{n}\cdot\hat{s}\,ds\,d\omega\,d\nu\overbrace{dt}^{dl = c\,dt}
\\
& = I_\nu\,\overbrace{ds\dfrac{dl}{c}}^{dV/c}\,d\omega\,d\nu
\\
\dfrac{dE}{dV\,d\nu} &= \dfrac{I_\nu}{c}\,d\omega = du_\nu
\end{aligned}$

Em $dt$ consideramos que os fótons preenchem todo o espaço, de forma que $dl = c\, dt$. $du_\nu$ é a densidade de energia, em um intervalo de frequências $d\nu$, devida a fótons vindo de um ângulo sólido $d\omega$. Disso segue

$$\begin{aligned}
u_\nu(\vec{r},t) &= \oint I_\nu\,d\omega
\\
& = \dfrac{1}{c} \oint I_\nu(\vec{r}, \hat{n}, t)\, d\omega
\\
& = \dfrac{4\pi}{c} J_\nu(\vec{r}, t)
\end{aligned}$$

Em um corpo negro

$$⁍$$

## Fluxo

Definimos fluxo físico como

$$\vec{f}(\vec{r},t) = \oint I_\nu(\vec{r},\hat{n},t)\,\hat{n}\,d\omega$$

Outras grandezas similares ao fluxo físico são os momentos do campo de radiação. A equação geral dos momentos do campo de radiação é

$$M_n(z) = \dfrac{1}{2} \int\limits_{1}^{-1} I_\nu(z,\mu)\,\mu^n\,d\mu$$

Os principais momentos são $M_0 = J_\nu$ e $M_1 = H_\nu$. $J_\nu$ é a intensidade média e $H_\nu$ é conhecido como fluxo de Eddington. $H_\nu$ quantifica o fluxo líquido de energia em uma região.

### Fluxo de um sistema isotrópico

$\vec{f}(\vec{r},t) = 0$ em um sistema isotrópico, pois não há transporte líquido de energia para nenhuma direção — isto é, a própria definição de isotropia. Matematicamente, isso se torna claro

$$\displaystyle\vec{f}(\vec{r}, t)= \oint I_\nu(\vec{r},\hat{n},t)\,\hat{n}\,d\omega = \oint B_{\nu}(T)\,\hat{n}\, d\omega = B_{\nu}(T)\oint \hat{n}\, d\omega = 0$$

Aqui o argumento é que a resultante da soma vetorial dos versores em todas as direções é nula.

### Caso plano-paralelo estacionário

Para realizar o cálculo em coordenadas cartesianas, precisamos das componentes e versores dados por

$\vec{f} = (f_x, f_y, f_z)$

$f_i = \oint I_\nu\,n_i\,d\omega$

Onde os valores de $n_i$ podem ser derivados em duas dimensões e generalizados

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/g62551.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/g62551.png)

$\hat{n} = n_x\,\hat{x} + n_y\,\hat{y} + n_z\,\hat{z}$

$\begin{aligned}d\vec{s} &= ds\hat{n} = dx\,\hat{x} + dy\,\hat{y}= n_x\,ds\,\hat{x} + n_y\,ds\,\hat{y}\end{aligned}$

$\begin{aligned}&d\vec{s}\cdot\hat{x} = dx = n_x\,ds \implies n_x = \dfrac{dx}{ds}\\&\implies n_i = \dfrac{dx_i}{ds}\end{aligned}$

Em três dimensões

$\begin{aligned}\vec{s} &= x\,\hat{x} + y\,\hat{y} + z\,\hat{z}\\ &= s\,\sin\theta\,\cos\phi\, \hat{x} + s\,\sin\theta\,\sin\phi\, \hat{y} + s\,\cos\theta\,\hat{z}\end{aligned}$

e da definição para $n_i$ temos:

$\begin{cases}
n_x = \sin\theta\,\cos\phi\\
n_y = \sin\theta\,\sin\phi\\
n_z = \cos\theta
\end{cases}$

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/g44944.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/g44944.png)

As componente do fluxo nesse caso são

$$\begin{cases}
f_x = \oint I_\nu\sin\theta^2\,\cos\phi = 0\\
f_y = \oint I_\nu\sin\theta^2\,\sin\phi = 0\\
f_z = \oint I_\nu \cos\theta\sin\theta\,d\theta\,d\phi = 2\pi\int\limits_0^{2\pi}I_\nu(z,0)\cos\theta\,\sin\theta\,d\theta = 2\pi\int\limits_{-1}^{1} I_\nu\, \mu\,d\mu
\end{cases}$$

No caso de um corpo negro, teríamos $f_z = 0$. Apesar disso, podemos calcular o fluxo na direção do observador considerando a contribuição de apenas um hemisfério

$$\begin{aligned}
f_z &= \vec{f}\cdot\hat{z}\\
&= \oint B_\nu\, \hat{n}\cdot\hat{z} d\omega\\
&= \oint B_\nu\,\cos\theta d\omega\\
&= B_\nu\int\limits_0^2\pi\int\limits_0^{\pi/2}\cos\theta\,\sin\theta\,d\theta\,d\phi
&=\pi\,B_\nu
\end{aligned}$$

# ⭐ Interação da radiação com a matéria

[Aula 1: revisão da última aula (presencial) + opacidade e emissividade](https://www.youtube.com/watch?v=469-KCGIqp4)

A forma como descrevemos a interação entre a radiação e a matéria é feita através da definição de coeficientes materiais. Sabemos que o campo de radiação é completamente caracterizado se temos $I_\nu$. No entanto, não sabemos como calcular/derivar essa grandeza.

Com o propósito de calculá-la, vamos definir duas grandezas macroscópicas essenciais: opacidade e emissividade do gás.

## Coeficiente de absorção/opacidade do gás

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/path2201.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/path2201.png)

gás (átomos, íons, elétrons, moléculas, prótons etc)

Qual a intensidade $I_\nu'$ que emerge após interação com o gás?

Definimos $\chi_\nu(\vec{r},\hat{n},t)$ como a opacidade na frequência $\nu$  e no ponto r devida a fótons indo na direção n no instante t.

Definimos $\chi_\nu(\vec{r},\hat{n},t)$ através da quantidade de energia absorvida por um elemento de volume com gás

$$dE = I_\nu(\vec{r},\hat{n},t)\,\chi_\nu(\vec{r},\hat{n},t)\,\overbrace{dA\,ds}^{dV}\,dt\,d\omega\,d\nu$$

$$⁍$$

O produto $\chi_\nu I_\nu$ é um compromisso entre as duas grandezas que afetam a energia absorvida

Depende de $I_\nu$ no ponto, pois a extingue

No nosso caso $\chi_\nu(z)$ — p-p estacionário e isotrópico

$l_\nu = \dfrac{1}{\chi_\nu}$

livre caminho médio  ($cm^{-1}$)

$\chi_\nu = n\, \sigma_\nu$

densidade numérica ($cm^{-3}$)

seção de choque ($cm^2$)

$\chi_\nu = \kappa_\nu \,\rho$

seção por massa ($m^2/g$)

densidade (g/m^3)

$\chi_\nu(z)$ pode ser bastante complicado de forma a não poder ser escrita analiticamente

Pode ser bem complexa

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%203.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%203.png)

## Coeficiente de emissão/emissividade do gás

É um processo que independe do campo de radiação. Os únicos fatores que afetam a emissividade são as propriedades do material.

O gás de forma intrínseca pode adicionar fótons na linha de visada

Não confundir com transmissividade, a emissividade pode ser causada por:

- Bremsstrahlung;
- recombinação;
- excitação;
- fluorescência;
- espalhamento

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/g4704.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/g4704.png)

Definimos a partir da quantidade de energia radiativa emitida por um elemento de volume.

$$dE=\eta_\nu(\vec{r}, \hat{n}, t) \, dA\, ds\, dt\, d\omega\, d\nu\\
[\eta_\nu] = erg /({cm}^{3} \, s\,\,Hz\,\,ster)$$

---

## Equação de transporte radiativo

Com essa equação iremos encontrar a intensidade específica do gás. Vamos derivá-la a partir dos conceitos apresentados.

Inicialmente, vamos imaginar um volume infinitesimal e construir a equação de transporte ao longo do feixe observado

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%204.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%204.png)

$$⁍$$

$$\tag{1} \Delta E=E_{out}+E_{i n}=\left[I_{V}\left(s{+} d s, t{+} d t\right)-I_{V}(s, t)\right]\, d A\, d t\, d \omega\, d \nu$$

$$\begin{cases}
E_{absorvida} = \chi_{\nu}\, I_{\nu}\, d A\, ds\, d t\, d\omega\, d\nu\\
E_{emitida} = \eta_{\nu}\,d A\, ds\, d t\, d\omega\, d\nu\\
\end{cases}$$

$$\tag{2} \Delta E=E_{emitida}-E_{absorvida}$$

- Digressão sobre diferenciais totais

    ![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%205.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%205.png)

Igualando as expressões (1) e (2):

$$\begin{aligned}
\left(\eta_\nu-\chi_{\nu} I_{\nu}\right) dA\, d s\, d t\, d \omega\, d \nu & = \left[I_\nu\left(s+d{s}, t+d t\right)-I_\nu(s, t)\right]\, dA\, d\omega\, d t\, d \nu
\\
\left(\eta_\nu-\chi_{\nu} I_{\nu}\right) \cancel{dA}\, {d s}\, \bcancel{d t}\, \cancel{d \omega}\, \bcancel{d \nu} &= \left[I_\nu\left(s+d{s}, t+d t\right)-I_\nu(s, t)\right]\, \cancel{dA}\, \cancel{d\omega}\, \bcancel{d t}\, \bcancel{d \nu}
\\
\left(\eta_\nu-\chi_{\nu} I_{\nu}\right)\,ds &= \left[I_\nu\left(s+d{s}, t+d t\right)-I_\nu(s, t)\right] = dI_\nu(s,t)
\\
\left(\eta_\nu-\chi_{\nu} I_{\nu}\right)\,ds &= 
\left(\frac{\partial I_{\nu}}{\partial s} ds + \frac{\partial I_{\nu}}{\partial t} dt\right)
\\
\left(\eta_\nu-\chi_{\nu} I_{\nu}\right)\,\cancel{ds} &= 
\left({\frac{\partial I_{\nu}}{\partial s}} + \dfrac{1}{c}\frac{\partial I_{\nu}}{\partial t}\right)\cancel{ds}
\\
\left(\eta_\nu-\chi_{\nu} I_{\nu}\right) &= 
\left({\frac{\partial I_{\nu}}{\partial s}} + \dfrac{1}{c}\frac{\partial I_{\nu}}{\partial t}\right)
\end{aligned}$$

NB: no caso estacionário: $d I_{\nu} / d s=\eta_{v}-\chi_{\nu} I_{\nu}$

Para escrever generalizar a direção em coordenadas cartesianas, basta usar as componentes do vetor $\hat{n}$ derivadas [aqui](https://www.notion.so/Processos-Radiativos-5511513688324e63b06ec7977c914da0#652a8a826cb64bc791e980ee7af84057), de forma que

$$\tag{*} \begin{aligned}
\dfrac{\partial f}{\partial s} &= \dfrac{\partial f}{\partial x}\dfrac{\partial x}{\partial s} + \dfrac{\partial f}{\partial y}\dfrac{\partial y}{\partial s} + \dfrac{\partial f}{\partial z}\dfrac{\partial z}{\partial s}
\\
&= \dfrac{\partial f}{\partial x}\,n_x + \dfrac{\partial f}{\partial y}\,n_y + \dfrac{\partial f}{\partial z}\,n_z
\\
& = \left(n_i\,\dfrac{\partial}{\partial i}\right) f
\\
 & =(\hat{n} \cdot \vec{\nabla}) f
\end{aligned}$$

Com isso podemos escrever

$$\begin{aligned}
\left(\eta_\nu-\chi_{\nu} I_{\nu}\right) &= 
\left(\underbrace{\frac{\partial I_{\nu}}{\partial s}}_{(*)} + \dfrac{1}{c}\frac{\partial I_{\nu}}{\partial t}\right)
\\
\left[\hat{n} \cdot \nabla+\frac{1}{c} \frac{\partial}{\partial t}\right] I_\nu\left(\vec{r}, \hat{n}, t\right)&=\eta_{\nu}\left(\vec{r}, \hat{n},t\right)-\chi_{\nu}\left(\vec{r}, \hat{n},t\right)\,I_\nu(\vec{r}, \hat{n}, t)
\end{aligned}$$

[Aula 2: eq. transporte radiativo e soluções](https://www.youtube.com/watch?v=tUfp37li-hA&feature=youtu.be)

### Caso plano-paralelo

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%206.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%206.png)

### ⚡ Profundidade ótica

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%207.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%207.png)

‼️ Exercício do Mihalas na geometria esférica

$\tau_\nu \ge 0$, adimensional, $d\tau_\nu := \chi_\nu(z) dz$

a relação entre $\tau_\nu$ e $z$ é unívoca

É vantajoso trabalharmos com profundidade ótica $\tau_\nu$. Vamos definir:

$d\tau_\nu \equiv -\chi_\nu\, dz$

$\tau_\nu(z) = - \int\limits_{z_{max}}^{z} \chi_\nu(z')\,dz'$

adimensional

unívoco

O caso pp estacionário fica

$\mu \, \dfrac{\partial I_{\nu}}{\partial z} \, \dfrac{1}{\chi_{\nu}}=\dfrac{\eta_{\nu}}{\chi_{\nu}} - I_{\nu}\\
- \mu \, \dfrac{\partial I_{\nu}}{\partial z} \, \dfrac{dz}{\tau_{\nu}}=\dfrac{\eta_{\nu}}{\chi_{\nu}} - I_{\nu}\\
\mu \, \dfrac{\partial I_{\nu}}{\partial z} \, \dfrac{dz}{\tau_{\nu}}=I_{\nu} - \dfrac{\eta_{\nu}}{\chi_{\nu}}$

O sinal é uma convenção pos z e tau aumentam em sentidos opostos

### Função fonte

Definimos $S_\nu(\tau_\nu)$ ou $S_\nu(z)$ como $S_\nu \coloneqq \dfrac{\eta_\nu}{\chi_\nu} = \dfrac{\text{emissão}}{\text{absorção}}$. Se não há emissão, $\eta_\nu = 0$, a função fonte é nula. Com essa definição, o caso plano-paralelo estacionário passa a ser ${\mu \dfrac{dI_\nu}{d\tau_\nu} = I_\nu - S_\nu}$.

## Soluções da equação de transporte

[Aula 3: solução geral; Eddington-Barbier; Aprox. da difusão - campo no interior estelar.](https://www.youtube.com/watch?v=nHAG052pG9E&feature=youtu.be)

[Core Capability 4 - Radiative Transfer Research](https://www.nasa.gov/content/core-capability-4-radiative-transfer-research)

> Radiative Transfer (RT) is a fundamental topic needed to interpret all remote observations spanning airless bodies, atmospheres of exoplanets and solar system bodies, protoplanetary disks, and all other astronomical objects. These complex applications require a comprehensive toolset of custom codes and extensive databases of optical properties and atomic and molecular line data.

[Dwarf Galaxies at the cutting EDGE of galaxy formation](https://astrobites.org/2020/07/03/dwarf-galaxy-edge/)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%208.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%208.png)

> **Finding a home for the dwarf galaxy**

The authors make use of RAMSES-RT, which is a radiation hydrodynamics code that allows them to investigate the physics of hydrodynamics, radiative transfer, and non-equilibrium radiative cooling/heating on the properties of dwarf galaxies. The authors choose to study one dwarf galaxy that forms in isolation – this allows them to probe down to high resolution limits while avoiding the additional complexities (both theoretical and computational) of simulating a host galaxy.

Até o momento, podemos escrever a equeção de transporte para o caso plano-paralelo estacionário como

$$\mu \dfrac{dI_\nu(z,\mu)}{dz} = \eta_\nu - \chi_\nu I_\nu$$

$$\mu \dfrac{dI_\nu(\tau_\nu, \mu)}{d\tau_\nu} = I_\nu - S_\nu(\tau_\nu)$$

### Opacidade e emissividade nulas

$$⁍$$

Na ausência de gás, o feixe de radiação não se altera. Vale notar que o fluxo cai com o quadrado da distância, mas a intensidade específica não.

### Opacidade nula

$$\begin{aligned}\mu \dfrac{dI_\nu(z,\mu)}{dz} &= \eta_\nu\\
{dI_\nu(z,\mu)} &= \eta_\nu\,{dz}\\
\int\limits_{I_\nu(z_1,\mu)}^{I_\nu(z_2,\mu)} dI_\nu &= \int\limits_{z_1}^{z_2}\dfrac{\eta_\nu}{\mu}\,dz\\
I_\nu(z_2,\mu) &= I_\nu(z_1,\mu) + \dfrac{1}{\mu} \int\limits_{z_1}^{z_2}{\eta_\nu}\,dz
\end{aligned}$$

$\eta_\nu \ge 0$, portanto o feixe ganha energia dependendo da emissividade. Esse caso ocorre, por exemplo, em nebulosas planetárias.

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%209.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%209.png)

### Emissividade nula

$$\begin{aligned}
\mu \dfrac{dI_\nu(\tau_\nu, \mu)}{d\tau_\nu} &= I_\nu - \cancel{S_\nu(\tau_\nu)}\\
\dfrac{dI_\nu(\tau_\nu, \mu)}{I_\nu} &=\dfrac{d\tau_\nu}{\mu} \\
\int\limits_{I_\nu(\tau_1,\mu)}^{I_\nu(\tau_2,\mu)} \dfrac{dI_\nu(\tau_\nu, \mu)}{I_\nu} &= \dfrac{1}{\mu}\int\limits_{\tau_1}^{\tau_2} d\tau_\nu\\
\ln\left(\frac{I_\nu(\tau_2,\mu)}
{I_\nu(\tau_1,\mu)}\right) &= \dfrac{1}{\mu} (\tau_2 - \tau_1)\\
\ln\left({I_\nu(\tau_2,\mu)}
\right) &= \dfrac{1}{\mu} (\tau_2 - \tau_1) + \ln\left({I_\nu(\tau_1,\mu)}
\right)\\\\
{I_\nu(\tau_2,\mu)}
&= {I_\nu(\tau_1,\mu)}e^{\frac{(\tau_2 - \tau_1)}{\mu}}

\end{aligned}$$

Se $\tau_2 = \tau(z_{topo}) = 0$ e $\tau_1 = \tau$, lembrando que profundidade ótica cresce de fora para dentro:

$${I_\nu(0,\mu)}
= {I_\nu(\tau,\mu)}e^{- \frac{\tau}{\mu}}$$

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2010.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2010.png)

Isso significa que a radiação emergente sofre atenuação exponencial.

Para $\mu = 1$:             ${I_\nu(0,1)}
= {I_\nu(\tau,1)}e^{-\tau}$

Se $\tau = 1$:              ${I_\nu(0,1)}
= \dfrac{I_\nu(1,1)}{e}$

- $\tau > 1$: meio espesso
- $\tau<1$: meio fino
- $\tau = 0$: meio transparente, como no vácuo

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2011.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2011.png)

### 🛑⬆️Solução geral

$$\begin{aligned}\mu \dfrac{dI_\nu(\tau_\nu, \mu)}{d\tau_\nu} &= I_\nu - S_\nu(\tau_\nu)\\
\dfrac{dI_\nu(\tau_\nu, \mu)}{d\tau_\nu} - \dfrac{I_\nu}{\mu} &=  -\dfrac{S_\nu(\tau_\nu)}{\mu}\\

\end{aligned}$$

Essa equação diferencial linear de primeira ordem pode ser resolvida multiplicando por $e^{-\int{1/\mu}\, d\tau}$ e usando que

$$\begin{aligned}\dfrac{d\,\{e^{-\tau/\mu}\,I_\nu(\tau_\nu, \mu)\}}{d\tau_\nu} = -\dfrac{e^{-\tau/\mu}\,I_\nu(\tau_\nu, \mu)}{\mu} + e^{-\tau/\mu}\dfrac{dI_\nu(\tau_\nu, \mu)}{d\tau_\nu}\\

\end{aligned}$$

Substituindo essa relação na equação diferencial

$$\begin{aligned}
e^{-\tau/\mu}\dfrac{dI_\nu(\tau, \mu)}{d\tau_\nu} - e^{-\tau/\mu}\dfrac{I_\nu}{\mu} &= -e^{-\tau/\mu}\dfrac{S_\nu(\tau_\nu)}{\mu}
\\
\dfrac{d\,\{e^{-\tau/\mu}\,I_\nu(\tau_\nu, \mu)\}}{d\tau_\nu} &=- e^{-\tau/\mu}\dfrac{S_\nu(\tau_\nu)}{\mu}
\\
{d\,\{e^{-\tau/\mu}\,I_\nu(\tau_\nu, \mu)\}} &= -e^{-\tau/\mu}\dfrac{S_\nu(\tau_\nu)}{\mu}{d\tau_\nu}\\
\int\limits_{\tau_2}^{\tau_1}{d\,\{e^{-\tau/\mu}\,I_\nu(\tau_\nu, \mu)\}} &= -\dfrac{1}{\mu}\int\limits_{\tau_2}^{\tau_1}S_\nu(\tau_\nu)e^{-\tau/\mu}{d\tau_\nu}
\\
e^{-\tau_2/\mu}\,I_\nu(\tau_{\nu_2}, \mu) - e^{-\tau_1/\mu}\,I_\nu(\tau_{\nu_1}, \mu) &= -\dfrac{1}{\mu}\int\limits_{\tau_2}^{\tau_1}S_\nu(\tau_\nu)e^{-\tau/\mu}{d\tau_\nu}
\\
e^{-\tau_1/\mu}\,I_\nu(\tau_{\nu_1}, \mu) &= e^{-\tau_2/\mu}\,I_\nu(\tau_{\nu_2}, \mu) + \dfrac{1}{\mu}\int\limits_{\tau_2}^{\tau_1}S_\nu(\tau_\nu)e^{-\tau/\mu}{d\tau_\nu}
\\
I_\nu(\tau_{1}, \mu) &= I_\nu(\tau_{2}, \mu)e^{-(\tau_2-\tau_1)/\mu} + \dfrac{1}{\mu}\int\limits_{\tau_1}^{\tau_2}S_\nu(\tau_\nu)e^{-(\tau-\tau_1)/\mu}{d\tau_\nu}
\end{aligned}$$

**Condições de contorno**

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2012.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2012.png)

Na geometria p-p, vamos considerar a condição da atmosfera semi-infinita de forma que

$$⁍$$

- Situação $\mu > 0$ (para forma da estrela):

$\tau_2 = \infty$, portanto:

$$⁍$$

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2013.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2013.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2014.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2014.png)

- Situação $\mu < 0$:

Nesse caso, $\tau_2 = 0$ e iremos supor que a estrela não possui companheira, de forma que $I_\nu(0,\mu) = 0$.

$$\begin{aligned}
I_\nu(\tau_{1}, \mu) & = \cancel{I_\nu(\tau_{2}, \mu)}e^{-(\tau_2-\tau_1)/\mu} + \dfrac{1}{\mu}\int\limits_{\tau_1}^{0}S_\nu(\tau_\nu)e^{-(\tau-\tau_1)/\mu}{d\tau_\nu}
\\
& = \dfrac{1}{\mu}\int\limits_{\tau_1}^{0}S_\nu(\tau_\nu)e^{-(\tau-\tau_1)/\mu}{d\tau_\nu}
\end{aligned}$$

## Campo de radiaçao em uma atmosfera estelar

$$I_\nu(\tau,\mu) = \begin{cases}\dfrac{1}{\mu}\int\limits_{\tau_1}^{\infty}S_\nu(\tau_\nu)e^{-(\tau-\tau_1)/\mu}{d\tau_\nu};\; \mu > 0
\\\\
\dfrac{1}{\mu}\int\limits_{\tau_1}^{0}S_\nu(\tau_\nu)e^{-(\tau-\tau_1)/\mu}{d\tau_\nu};\; \mu < 0\end{cases}$$

$$⁍$$

A solução para $I_\nu(\tau,\mu)$ fica em função de $S_\nu$ para várias profundidades $[0,+\infty)$ e isso acopla a parte do gás, tornando o problema muito complexo pois precisamos conhecer $\chi_\nu$ e $\eta_\nu$ em toda a atmosfera.

### 🛑 Relação de Eddington-Barbier

Contornando a complexidade de ter um $S_\nu$ realista ao fazer uma aproximação linear. Seja $S_\nu (t) = a + bt$, a intensidade emergente é

$$⁍$$

Então temos que $I_\nu(0,\mu) = S_\nu(t=\mu) = a + \mu b$ e

$$⁍$$

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2015.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2015.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2016.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2016.png)

### Equações de Schwarzschild-Milne

Se temos a solução para uma atmosfera ($I_\nu$), temos tudo o que precisamos para calcular $J_\nu$ e $H_\nu$

$$J_{\nu} = \dfrac{1}{2} \int_{-1}^{+1} I_{\nu}(\tau,\mu)d\mu\\H_{\nu} = \dfrac{1}{2} \int_{-1}^{+1} \mu I_{\nu}(\tau,\mu) d\mu\\K_{\nu} = \dfrac{1}{2} \int_{-1}^{+1} \mu^{2} I_{\nu}(\tau,\mu) d\mu$$

Partindo da seguinte expressão para a intensidade do campo de radiação:

$$\begin{aligned}
I_{\nu}(\tau,\mu) = \begin{cases}
\frac{1}{\mu} \int_{\tau}^{\infty} S_{\nu} (t) e^{-(t-\tau)/\mu} dt, & \text{se }\mu > 0 \\
\frac{1}{\mu} \int_{\tau}^{0} S_{\nu} (t) e^{-(t-\tau)/\mu} dt, & \text{se }\mu < 0 \\
\end{cases}
\end{aligned}$$

- $J_{\nu} = \dfrac{1}{2} \int_{0}^{\infty} S_{\nu} (t) E_1 (|t-\tau|)dt$

    $\begin{aligned}
    J_{\nu} &= \dfrac{1}{2}\left[ \int_{-1}^{0} \frac{1}{\mu} \int_{\tau}^{0} S_{\nu} (t) e^{-(t-\tau)/\mu} dt d\mu + \int_{0}^{+1} \frac{1}{\mu} \int_{\tau}^{\infty} S_{\nu} (t) e^{-(t-\tau)/\mu} dt d\mu \right]\\
    &= \dfrac{1}{2}\left[ \int_{-1}^{0} \int_{\tau}^{0} \frac{1}{\mu} S_{\nu} (t) e^{-(t-\tau)/\mu} dt d\mu + \int_{0}^{+1} \int_{\tau}^{\infty} \frac{1}{\mu} S_{\nu} (t) e^{-(t-\tau)/\mu} dt d\mu \right]\\
    &\text{Fazemos $\frac{1}{|\mu|} = w \Rightarrow d\mu = \mp \frac{dw}{w^2}$:}\\
    &= \dfrac{1}{2}\left[ \int_{1}^{\infty} \int_{\tau}^{0} -w S_{\nu} (t) e^{w(t-\tau)} dt \frac{dw}{w^2} + \int_{\infty}^{1} \int_{\tau}^{\infty} w S_{\nu} (t) e^{-w(t-\tau)} dt \frac{-dw}{w^2} \right]\\
    &= -\dfrac{1}{2}\left[ \int_{1}^{\infty} \int_{\tau}^{0}w^{-1} S_{\nu} (t) e^{w(t-\tau)} dt dw + -\int_{\infty}^{1} \int_{\tau}^{\infty} w^{-1} S_{\nu} (t) e^{-w(t-\tau)} dtdw \right]\\
    &= \dfrac{1}{2}\left[ \int_{1}^{\infty} \int_{0}^{\tau}w^{-1} S_{\nu} (t) e^{w(t-\tau)} dt dw + \int_{1}^{\infty} \int_{\tau}^{\infty} w^{-1} S_{\nu} (t) e^{-w(t-\tau)} dtdw \right]\\
    &\text{Separando os termos independentes de $w$ e fazendo $(t-\tau) = -|t-\tau|$ para $0 < t < \tau$ e $(t-\tau) = |t-\tau|$ para $\tau < t < \infty$:}\\
    &= \dfrac{1}{2}\left[ \int_{0}^{\tau} S_{\nu} (t) dt \int_{1}^{\infty} w^{-1} e^{-w|t-\tau|} dw + \int_{\tau}^{\infty} S_{\nu} (t) dt \int_{1}^{\infty} w^{-1} e^{-w|t-\tau|} dw \right]\\
    &\text{Utilizando a integral exponencial $E_n (x) = \int_{1}^{\infty} t^{-n} e^{-xt}$ com $n=1$:}\\
    &= \dfrac{1}{2}\left[ \int_{0}^{\tau} S_{\nu} (t) E_1 (|t-\tau|)dt + \int_{\tau}^{\infty} S_{\nu} (t) E_1 (|t-\tau|)dt \right]\\
    &= \dfrac{1}{2}\left[ \int_{0}^{\infty} S_{\nu} (t) E_1 (|t-\tau|)dt \right]\\
    \end{aligned}$

- $H_{\nu} = \dfrac{1}{2}\int_{\tau}^{\infty} S_{\nu} E_2 (t-\tau)(t)dt -\dfrac{1}{2}\int_{0}^{\tau}S_{\nu} (t) E_2 (\tau-t) dt$

    $\begin{aligned}
    H_{\nu} = \dfrac{1}{2}\left[\int_{-1}^{0} \frac{1}{\mu} \int_{\tau}^{0} \mu S_{\nu} (t) e^{-(t-\tau)/\mu} dt d\mu + \int_{0}^{+1} \frac{1}{\mu} \int_{\tau}^{\infty} \mu S_{\nu} (t) e^{-(t-\tau)/\mu} dt d\mu \right]\\
    = \dfrac{1}{2}\left[\int_{-1}^{0}\int_{\tau}^{0} S_{\nu} (t) e^{-(t-\tau)/\mu} dt d\mu + \int_{0}^{+1} \int_{\tau}^{\infty} S_{\nu} (t) e^{-(t-\tau)/\mu} dt d\mu \right]\\
    \text{Fazendo a mesma substição que antes, $\frac{1}{|\mu|} = w \Rightarrow d\mu = \mp \frac{dw}{w^2}$}\\
    = \dfrac{1}{2}\left[\int_{+1}^{\infty}\int_{\tau}^{0}w^{-2} S_{\nu} (t) e^{w(t-\tau)} dt dw - \int_{\infty}^{+1} \int_{\tau}^{\infty} w^{-2}S_{\nu} (t) e^{-w(t-\tau)} dt dw \right]\\
    = \dfrac{1}{2}\left[-\int_{+1}^{\infty}\int_{0}^{\tau} w^{-2}S_{\nu} (t) e^{w(t-\tau)} dt dw + \int_{+1}^{\infty} \int_{\tau}^{\infty} w^{-2}S_{\nu} (t) e^{-w(t-\tau)} dt dw \right]\\
    = \dfrac{1}{2}\left[-\int_{0}^{\tau}S_{\nu} (t) dt \int_{+1}^{\infty}dt w^{-2}e^{-w(\tau-t)} dw + \int_{\tau}^{\infty}S_{\nu} (t) dt\int_{+1}^{\infty} w^{-2} e^{-w(t-\tau)} dw \right]\\
    = \dfrac{1}{2}\left[-\int_{0}^{\tau}S_{\nu} (t) E_2 (\tau-t) dt + \int_{\tau}^{\infty} S_{\nu} E_2 (t-\tau)(t) dt\right]\\
    \end{aligned}$

- $K_{\nu} = \dfrac{1}{2}\int_{0}^{\infty} S_{\nu} (t)E_3 (|t-\tau|)dt$

    $\begin{aligned}
    K_{\nu} = \dfrac{1}{2}\left[\int_{-1}^{0} \frac{1}{\mu} \int_{\tau}^{0} \mu^{2} S_{\nu} (t) e^{-(t-\tau)/\mu} dt d\mu + \int_{0}^{+1} \frac{1}{\mu} \int_{\tau}^{\infty} \mu^{2} S_{\nu} (t) e^{-(t-\tau)/\mu} dt d\mu \right]\\
    = \dfrac{1}{2}\left[\int_{-1}^{0}\int_{\tau}^{0} \mu S_{\nu} (t) e^{-(t-\tau)/\mu} dt d\mu + \int_{0}^{+1} \int_{\tau}^{\infty} \mu S_{\nu} (t) e^{-(t-\tau)/\mu} dt d\mu \right]\\
    = \dfrac{1}{2}\left[\int_{+1}^{\infty}\int_{\tau}^{0} -\frac{1}{w} S_{\nu} (t) e^{w(t-\tau)} dt \frac{dw}{w^2} + \int_{\infty}^{+1} \int_{\tau}^{\infty} \frac{1}{w} S_{\nu} (t) e^{-w(t-\tau)} dt \frac{-dw}{w^2} \right]\\
    = \dfrac{1}{2}\left[\int_{0}^{\tau} S_{\nu} (t)dt \int_{+1}^{\infty} w^{-3} e^{w(t-\tau)} dw + \int_{\tau}^{\infty}S_{\nu} (t) dt\int_{+1}^{\infty} w^{-3} e^{-w(t-\tau)} dw \right]\\
    = \dfrac{1}{2}\left[\int_{0}^{\tau} S_{\nu} (t)dt \int_{+1}^{\infty} w^{-3} e^{-w|t-\tau|} dw + \int_{\tau}^{\infty}S_{\nu} (t) dt\int_{+1}^{\infty} w^{-3} e^{-w|t-\tau|} dw \right]\\
    = \dfrac{1}{2}\left[\int_{0}^{\tau} S_{\nu} (t)E_3 (|t-\tau|)dt + \int_{\tau}^{\infty}S_{\nu} (t) E_3 (|t-\tau|)dt \right]\\
    = \dfrac{1}{2}\left[\int_{0}^{\infty} S_{\nu} (t)E_3 (|t-\tau|)dt \right]\\
    \end{aligned}$

### 🛑 Aproximação da difusão

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2017.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2017.png)

A medida que caminhamos em direção ao interios estelar, sabemos intuitivamente que P, T e $\rho$ aumentam. Lá a opacidade é maior, portanto o livre caminho médio dos fótons é muito menor do que na atmosfera. Isso faz com que o meio "se torne" isotrópico.

Equilíbrio térmico e função fonte

$$⁍$$

O que implica em $\eta_\nu = I_\nu\chi_\nu = \eta_\nu B_\nu(T) \implies B_\nu(T) = \dfrac{\eta_\nu}{\chi_\nu} = S_\nu$, que é a lei da radiação de Kirchhoff-Planck.

Dessa forma, há uma relação unívoca, em profundidade, entre $S_\nu$ e $B_\nu$. No interior, vamos aproximar por uma expansão de Taylor:

$$S_\nu(t) \approxeq \left.\sum_{n=0}^{+\infty} \frac{d^{n} B_{v}}{d t^{n}} \right|_{\tau \ggg 1} \frac{(t-\tau)^{n}}{n !}$$

A **intensidade específica emergente** será

$$⁍$$

Esse último termo representa a anisotropia do campo.

[Aula 4: J e H no interior; fluxo radiativo no interior estelar; luminosidade de Eddington.](https://www.youtube.com/watch?v=LRU5Ip1Vic8&feature=youtu.be)

Agora podemos calcular a intensidade média e o fluxo nessa aproximação

$$\begin{aligned}
J_\nu(\tau) &= \dfrac{1}{2}\int\limits_{-1}^{+1} I_\nu(\tau,\mu)d\mu
\\
& = \dfrac{1}{2}\int\limits_{-1}^{+1} \left.\sum_{n=0}^{+\infty} \frac{d^{n} B_{\nu}}{d t^{n}} \right|_{\tau \ggg 1}\mu^{n}d\mu
\\
& = \dfrac{1}{2}\left.\sum_{n=0}^{+\infty} \frac{d^{n} B_{\nu}}{d t^{n}} \right|_{\tau \ggg 1}\int\limits_{-1}^{+1} \mu^{n}d\mu 
\\
& = \dfrac{1}{2}\left.\sum_{n=0}^{+\infty} \frac{d^{n} B_{\nu}}{d t^{n}} \right|_{\tau \ggg 1}\left.\dfrac{\mu^{n+1}}{n+1}\right|_{-1}^{+1}
\\
& = \dfrac{1}{2}\left.\sum_{n=0}^{+\infty} \frac{d^{n} B_{\nu}}{d t^{n}} \right|_{\tau \ggg 1}\dfrac{1}{n+1} (1^{n+1} - (-1^{n+1}))\\ &\text{Se $n$ é ímpar, $J_\nu = 0$. Com $n$ par:}
\\
& = \dfrac{1}{2}\left.\sum_{n=0}^{+\infty} \frac{d^{2n} B_{\nu}}{d t^{2n}} \right|_{\tau \ggg 1}\dfrac{1}{2n+1} (2) = \left.\sum_{n=0}^{+\infty} \dfrac{1}{2n+1} \frac{d^{2n} B_{\nu}}{d t^{2n}} \right|_{\tau \ggg 1}
\\
& \approx B_{\nu}(T) + \dfrac{1}{3}\left.\frac{d^{2} B_{\nu}}{d t^{2}}\right|_{\tau \ggg 1}
\end{aligned}$$

$$\begin{aligned}
H_\nu(\tau) &= \dfrac{1}{2}\int\limits_{-1}^{+1} I_\nu(\tau,\mu)\mu\,d\mu
\\
& = \dfrac{1}{2}\left.\sum_{n=0}^{+\infty} \frac{d^{n} B_{\nu}}{d t^{n}} \right|_{\tau \ggg 1}\dfrac{1}{n+2} (1 - (-1^{n+2}))\\ &\text{Se $n$ é par, $H_\nu = 0$. Com $n$ ímpar:}
\\
& =\left.\sum_{n=0}^{+\infty} \frac{d^{2n+1} B_{\nu}}{d t^{2n+1}} \right|_{\tau \ggg 1}\dfrac{1}{2n+3}
\\
& \dfrac{1}{3}\left.\frac{d B_{\nu}}{d t}\right|_{\tau \ggg 1}
\end{aligned}$$

Em suma: I, J e H são simples no interior. $H_\nu(\tau\ggg 1)$ é fundamental para entendermos a estrutura interna das estrelas, pois ele significa transporte de energia para o exterior. Vamos integrar $H_\nu$:

$$\\\begin{aligned}
H & = \int\limits_0^\infty \dfrac{1}{3}\left.\frac{d B_{\nu}}{d t}\right|_{\tau \ggg 1} d\nu = \dfrac{1}{3}\frac{d }{d \tau}\int\limits_0^\infty B_{\nu} d\nu\\
& = \dfrac{1}{3}\frac{d }{d \tau} a T^4 = \dfrac{4}{3}aT^3 \frac{dT}{d\tau}
\end{aligned}$$

Aplicando na definição de fluxo $F = 4\pi H$ e usando que $d\tau = -\chi dr$:

$$\dfrac{F}{4\pi} = \dfrac{4}{3}a \frac{dT}{d\tau} \implies F = - \dfrac{16 \pi a}{3\chi} T^3 \frac{dT}{dr}$$

1. Se o gradiente de temperatura é nulo, $F = 0$;
2. Se a opacidade é muito alta, $F\to0$;
3. A equação do fluxo é difusiva.

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2018.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2018.png)

### Limite de Eddington

Vimos que um elemento de volume $dV$ com opacidade $\chi_\nu$ poderá absorver energia seguindo ${d E = \chi_{\nu} I_{\nu} d A d s d t d \omega d \nu}$. Na absorção também há transferência de momento do campo de radiação para a matéria. Para os fótons, $dE = c\,dp$ e se toda a energia dos fótons é absorvida, temos

$$c \,d \vec{p}=\hat{n} \chi_{\nu} I_{\nu} d A d s d t d \omega d \nu
\\
\underbrace{\dfrac{d \vec{p}}{ d A d s d t  d \nu}}_{\vec{f}_\nu}=c^{-1}\hat{n} \chi_{\nu} I_{\nu} d \omega$$

$\vec{f}_\nu$ e uma espécie de força volumar, tendo unidade de força/volume/frequência, mas apenas em uma direção. A partir dela, podemos obter a força radiativa volumar ao integrar em todas as direções e frequências:

$$\vec{f}_{rad}(\vec{r},t) = \int_\nu\oint c^{-1} I_\nu \hat{n} \chi_\nu d\omega$$

Se $\chi_\nu$ é isotrópica

$$\vec{f}_{rad}(\vec{r},t) = \int_\nu c^{-1} \chi_\nu \oint  I_\nu \hat{n}  d\omega = \int\limits_0^\infty c^{-1} \chi_\nu \vec{F}_\nu d\nu$$

Todo gás astrofísico que absorve radiação está sujeito à uma força radiativa. Essa força pode até mesmo equilibrar e superar a força graviatacional.  O equilíbrio entre as forças em um gás astrofísico pode ser descrito, de forma simplificada, por:

$$\rho \frac{d \vec{v}}{d t}=-\nabla_{p}-\frac{G m \rho}{r^{2}} \hat{r}+\vec{f}_{r a d} = 0$$

Em um caso hipotético em que há apenas gravidade e a força radiativa, a situação limite ocorre quando ${f_{rad} = \dfrac{Gm\rho}{r^2}}$. Supondo um gás de hidrogênio puro e ionizado, sabemos que ${\chi_\nu = \chi = n_e\sigma_T}$ (espalhamento Thompson). Então ${f_{rad} = c^{-1} \chi F}$. Mas ${F = \dfrac{L}{4\pi r^2}}$ e ${\rho = n_Hm_H = n_em_H}$, de forma que podemos obter a luminosidade limite, conhecida como luminosidade de Eddington.

$$\frac{\chi L}{4 \pi c}=G M n_{e} m_{H}\implies
L_{edd}=\frac{4 \pi c G M n_{e} m_{H}}{\chi} = \frac{4 \pi c G M n_{e} m_{H}}{n_e\sigma_T}
\\
L_{edd} = \frac{4 \pi c G M m_{H}}{\sigma_T}
$$

[Aula 5a - Tensor pressão de radiação; Corpo Negro (aspectos básicos)](https://www.youtube.com/watch?v=MjwNoEuRL48&feature=youtu.be)

Olhas notas dessa aula na hora de desenvolver as contas

Pode ter mais forças aqui: força de lorenz devido a campo magnetico e força centrífuga graças a rotação

## Tensor pressão de radiação

$$\mathbb{P} \equiv c^{-1} \oint \hat{n}\hat{n} I_\nu(\vec{r},\hat{n},\tau) d\omega$$

Cada componente é dada por $P_{ij} = c^{-1} \oint{n}_i{n}_j I_\nu(\vec{r},\hat{n},\tau) d\omega$

No caso de equilíbrio termodinâmico, $I_\nu(\vec{r},\hat{n},\tau) = B_\nu(T)$ e o tensor fica

$$\begin{aligned}
P_{ij} & = c^{-1} \oint{n}_i{n}_j B_\nu(T) d\omega
\\
& = c^{-1} B_\nu(T) \oint{n}_i{n}_j d\omega
\\
& = c^{-1} B_\nu(T) \int\limits_0^{2\pi}\int\limits_0^{\pi}{n}_i{n}_j \sin\theta\,d\phi\,d\theta
\end{aligned}$$

$$\begin{aligned}P_{xj}& = c^{-1} B_\nu(T) \int\limits_0^{2\pi}\int\limits_0^{\pi}{n}_j \cos\phi\sin^2\theta\,d\phi\,d\theta
\\
P_{xx} &= c^{-1} B_\nu(T) \int\limits_0^{2\pi}\int\limits_0^{\pi} \cos^2\phi\sin^3\theta\,d\phi\,d\theta\\&= c^{-1} B_\nu(T) \int\limits_0^{2\pi}\cos^2\phi\,d\phi\int\limits_0^{\pi} \sin\theta(1 - \cos^2\theta)\,d\theta
\\
&= c^{-1} B_\nu(T) (1/2)\int\limits_0^{2\pi}1+\cos(2\phi)\,d\phi\int\limits_0^{\pi} \sin\theta - \cos^2\theta\sin\theta \,d\theta
\\
&= c^{-1} B_\nu(T)\left[ \pi + \int\limits_0^{\pi}\cos y\,dy \right]\left[\cos0 - \cos\pi + \int\limits_1^{-1} y^2 dy \right]\\&= c^{-1} B_\nu(T)\pi(2 -2/3) = B_\nu(T)4\pi/3c\\P_{xy}& = P_{yx} = c^{-1} B_\nu(T) \int\limits_0^{2\pi}\int\limits_0^{\pi}\underbrace{\sin\phi \cos\phi}_{ortogonais}\sin^3\theta\,d\phi\,d\theta = 0\\
P_{xz}& = P_{zx} = c^{-1} B_\nu(T) \int\limits_0^{2\pi}\int\limits_0^{\pi}\underbrace{\sin\phi \cos\phi}_{ortogonais}\sin^2\theta\,d\phi\,d\theta = 0
\\
\\
P_{yj}& = c^{-1} B_\nu(T) \int\limits_0^{2\pi}\int\limits_0^{\pi}{n}_j \sin\phi\sin^2\theta\,d\phi\,d\theta
\\
P_{yy}& = c^{-1} B_\nu(T) \int\limits_0^{2\pi}\int\limits_0^{\pi} \sin^2\phi\sin^3\theta\,d\phi\,d\theta\\
& = c^{-1} B_\nu(T) \int\limits_0^{2\pi}\sin^2\phi\,d\phi\int\limits_0^{\pi} \sin^3\theta\,d\theta\\
& = c^{-1} B_\nu(T) (1/2)\int\limits_0^{2\pi}1-\cos(2\phi)\,d\phi\int\limits_0^{\pi} \sin^3\theta\,d\theta\\
& = B_\nu(T)4\pi/3c
\\
P_{yz}& = Pzy = c^{-1} B_\nu(T) \int\limits_0^{2\pi}\int\limits_0^{\pi}\sin\phi\sin^2\theta\cos\theta\,d\phi\,d\theta
\\
& = c^{-1} B_\nu(T)(-\cos0 + \cos 2\pi)\int\limits_0^{\pi}\sin^2\theta\cos\theta\,d\theta = 0
\\
\\
P_{zj}& = c^{-1} B_\nu(T) \int\limits_0^{2\pi}\int\limits_0^{\pi}{n}_j \cos\theta\sin\theta\,d\phi\,d\theta
\\
P_{zz}& = c^{-1} B_\nu(T) \int\limits_0^{2\pi}\int\limits_0^{\pi}\cos^2\theta\sin\theta\,d\phi\,d\theta = c^{-1} B_\nu(T)  2 \pi\int\limits_0^{\pi}\cos^2\theta\sin\theta\,d\theta\\
&= c^{-1} B_\nu(T)  2 \pi(2/3) = B_\nu(T)4\pi/3c\\
\end{aligned}$$

Portanto

$$\mathbb{P} = \begin{pmatrix}
P_{xx} & 0 & 0 \\
0 & P_{yy} & 0\\
0 & 0 & P_{zz}
\end{pmatrix}$$

$P = \dfrac{4\pi}{3}\dfrac{B_\nu}{c} = \dfrac{4\pi}{3}\dfrac{J_\nu}{c} = \dfrac{u_\nu}{3}$

### Corpo negro

Por definição, é um corpo que absorve toda a radiação incidente; a radiação que emite é própria, característica de sua temperatura.

É um corpo idealizado! A coisa central do corpo negro é que a radiação que ele emite é prórpia: o corpo negro não espalha luz. A maior parte das coisas no dia-a-dia apenas espalham luz, e emitem muito pouco. O corpo negro absorve completamente a luz, sem espalhar e sua emissão é totalmente definida pela temperatura. Ele é um emissor e absorvedor ideal.

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2019.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2019.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2020.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2020.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2021.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2021.png)

A importância do corpo negro na astrofísica é que conhecemos muito bem suas propriedades, com o fato principal sendo sua dependência em T.

### Diferentes temperaturas

**Temperatura de brilho**

Fonte astrofísica em $\nu$ escolhido, fazer $I_\nu = B_\nu(T_B)$. Consiste em descobrir qual a curva de corpo negro que passa por esse valor de fluxo. Provar que as curvas de corpo negro de diferentes valores de T não se cruzam.

**Temperatura de cor**

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2022.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2022.png)

**Temperatura efetiva**

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2023.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2023.png)

## Termodinâmica de corpo negro

### Energia

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2024.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2024.png)

$d u=T d s-p d V \Rightarrow d s=\dfrac{d u}{T}+\dfrac{p}{T} d v; \quad S=s(u, v)$

$u_{\nu}=\dfrac{4 \pi}{c} J_{\nu}=\dfrac{4 \pi}{c}B_{\nu} \Rightarrow u=\dfrac{4 \pi}{c} B=f(T)$

$U=u V \Rightarrow d U=u d V+V d u = u d V + V \frac{d u}{d T} d T$

$$\begin{aligned}
d S &=\dfrac{1}{T} u d V+\dfrac{V}{T} \dfrac{d u}{d T} d T+\dfrac{p}{T} dV
\\
&=\left(\dfrac{u}{T}+\dfrac{p}{T}\right) d V+\dfrac{v}{T} \dfrac{d u}{d T} d T
\\
&=\dfrac{1}{T}\left(u+\dfrac{u}{3}\right) d V+\dfrac{V}{T} \dfrac{d u}{d T} d T\\&\therefore\quad S=S(V, T)
\end{aligned}$$

$$⁍$$

$\dfrac{\partial S}{\partial V}=\dfrac{4}{3} \dfrac{u}{T}$

$\dfrac{\partial S}{\partial T}=\dfrac{V}{T} \dfrac{d u}{d T}$

${\dfrac{\partial^{2} S}{\partial T \partial V}=\dfrac{\partial^{2} S}{\partial V \partial T}}$

$$\frac{\partial}{\partial T}\left(\frac{\partial S}{\partial V}\right)=\frac{\partial}{\partial T}\left(\frac{4}{3} \frac{u}{T}\right)=\frac{4}{3} \frac{1}{T} \frac{d u}{d T}-\frac{4}{3} \frac{u}{T^{2}}
\\
\frac{\partial}{\partial v}\left(\frac{\partial S}{\partial T}\right)=\frac{\partial}{\partial V}\left(\frac{V}{T} \frac{d u}{d T}\right)=\frac{1}{T} \frac{d u}{d T}
\\
\cancel{\frac{1}{T}} \frac{d u}{d T}=\frac{4}{3} \cancel{\frac{1}{T}} \frac{d u}{d T}-\frac{4}{3} \frac{\mu}{T^{\cancel{2}}}
\\
\frac{4}{3} \frac{u}{T}=\frac{1}{3} \frac{d u}{d T} \Rightarrow 4 \frac{d T}{T}=\frac{d u}{u}
\\
u(T) = aT^4$$

$$u = \dfrac{4\pi}{c} B \implies \overbrace{\pi B(T)}^{F} = \left(\dfrac{c a}{4 \pi}\right) T^4 \implies B = \dfrac{acT^4}{4}$$

### **Entropia**

$$⁍$$

Seja o processo com V constante

$$\begin{aligned}
dS &= \dfrac{V}{T}\dfrac{du}{dT} dT\\
 & = \dfrac{V}{T}\dfrac{d}{dT}(aT^4) dT\\
 & = \dfrac{V}{T}4aT^3 dT\\
 & = 4aVT^2 dT\\
\int\limits_{S_0}^{S} & = 4aV \int\limits_{T_0}^{T} T^2 dT\\
S & = \dfrac{4aVT^3}{3}
\end{aligned}$$

### Lei para expansão adiabática

dQ = T dS = 0

$$dS = \dfrac{V}{T} \dfrac{du}{dT} dT + \dfrac{4}{3} \dfrac{u}{T} dV\\
- \dfrac{V}{T} \cancel{4aT^3} dT = \dfrac{ \cancel{4aT^3} }{3} dV\\
- \dfrac{dT}{T} = \dfrac{dV}{3V}\\
T_i V_i ^{1/3} = T_jV_j^{1/3}\\
TV^{1/3} = cte$$

Lembrando que $p = \dfrac{u}{3} = \dfrac{aT^4}{3} = \dfrac{a}{3} \left(\dfrac{cte}{V^{1/3}}\right) \propto V^{-4/3} \implies pV^{4/3}$ (corpo negro)

Note que para o gás ideal, $pV^{5/3} = cte$.

### Radiação Cósmica de Fundo

$$⁍$$

$T \propto (1+z)$ ou $T = T_0(1+z)$ que descreve a evolução da temperatura da CMB.

$T_0 \sim 2.7K;\quad z\approx 1000\implies T(1000)\approx2700K$

## Coeficientes de Einstein

Aqui retornamos à parte microscópica do problema. Na equação de transporte temos

$$⁍$$

onde $\eta$ e $\chi$ são os coeficientes macroscópicos que reunem em si processos atômicos e moleculares. A descrição microscópica de alguns desses processos pode ser feita através dos coeficientes de Einstein.

Seja um átomos arbitrário de 2 níveis, os processos que podem acontecer são

ligado-ligado radiativas

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2025.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2025.png)

$\large B_{ij}$

### Absorção simples

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2026.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2026.png)

$$⁍$$

$n_i$ é a população eletrônica $\text{cm}^{-3}$

$B_{ij}$ está relacionado à probabilidade da transição $i\to j$. Definido pela quântica, é uma característica atômica.

$\phi_\nu$ é o perfil de absorção. $\int\limits_0^\infty \phi_\nu d\nu = 1$

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2027.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2027.png)

$\large B_{ji}$

### Emissão estimulada

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2028.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2028.png)

$$\frac{d n_{i}}{d t}=+\frac{1}{4 \pi} n_{j} B_{j i} I_{\nu} \psi_{\nu}$$

$\psi_\nu$  é o perfil de emissão.

$\left[B_{i j}\right]=\left[B_{j i}\right]$

$\large A_{ji}$

### Emissão espontânea

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2029.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2029.png)

$$\frac{d n_{i}}{d \tau}=+\frac{1}{4 \pi} n_{j} A_{ji} \psi_{\nu}$$

$\left[A_{y i}\right]=s^{-1}$

### Relações entre os coeficientes

Seja um gás em equilíbrio termodinâmico, há um balanço entre as transições e temos $I_\nu = B_\nu$ e $\phi_\nu = \psi_\nu$. Matematicamente, a contribuição de cada um dos tipos de transição é

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2030.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2030.png)

$$\left(\frac{d n_{i}}{d t}\right)_{ij}+\left(\frac{d n_{i}}{d t}\right)_{ji}+\left(\frac{d n_{i}}{d t}\right)_{j i}=0$$

$$-n_{i} B_{ij} B_{\nu}+n_{j} B_{j i} B_{v}+n_{j} A_{j i}=0\\
+n_{i} B_{ij} B_{\nu}\left(1  - \dfrac{n_{j}B_{j i}}{n_{i} B_{i}}\right)=+n_{j} A_{ji}
\\
B_{\nu}(T)=\frac{n_{j} A_{j^{i}} / n_{i} B_{ij}}{1-n_{j} B_{j i} / n_{i} B_{i j}}
$$

De Maxwell-Boltzmann:

$\dfrac{n_j}{n_i} = \dfrac{g_j}{g_i}e^{\frac{-h\nu}{kT}}$

$$\begin{cases}B_{\nu}(T)=\dfrac{\dfrac{g_{j}}{g_{i}} e^{-h\nu / k T} \dfrac{A_{j i}}{B_{ij}}}{1-\dfrac{g_j}{g i} e^{-h v / k T} \dfrac{B_{j i}}{B_{ij}}}=\dfrac{\dfrac{g_{j}}{g_{i}}\dfrac{A_{ji}}{B_{ij}}}{e^{h\nu / k T}-\dfrac{g_{j} B_{j i}}{g_{i} B_{i j}}}\\\\\\
B_{\nu}(T)=\dfrac{2 h v^{3}}{c^{2}} \dfrac{1}{e^{h v / k T}-1}\end{cases}
$$

Comparando

$\dfrac{g_{j} B_{j i}}{g_{i} B_{i j}} = 1 \implies g_{j} B_{j i} = g_{i} B_{i j}$

$\dfrac{g_{j}}{g_{i}}\dfrac{A_{ji}}{B_{ij}} = \dfrac{2 h v^{3}}{c^{2}} \implies {g_{j}}{A_{ji}} = \dfrac{2 h v^{3}}{c^{2}} {g_{i}}{B_{ij}} \implies {A_{ji}} = \dfrac{2 h v^{3}}{c^{2}} {B_{ji}}$ 

### Opacidade e emissividade em termos dos coeficientes de Einstein

Podemos construir

$$\begin{cases}
\eta_{\nu}=\dfrac{\eta_j A_{ji} h\nu \psi_{\nu}}{4 \pi} \\\\
\chi_{\nu}=\dfrac{n_{i} B_{i j} h{\nu} \phi_{\nu}-n_{j} B_{j} h \nu \psi_{\nu}}{4\pi}
\end{cases}$$

opacidade negativa (emissão estimulada)

basta saber $B_{i j} \leftrightarrow \alpha_{i j}, f_{i j}, \sigma_{i j}$

Temos portanto que resolver

$$\mu \frac{d I_{\nu}}{d z}=\frac{h \nu}{4 \pi}\left\{n_{j} A_{j i} \psi_{\nu}-\left[n_{i} B_{ij} \phi_{\nu}-n_{j} B_{ji} \psi_{\nu}\right] I_{\nu}\right\}$$

Sabemos as características atômicas, não sabemos $I_\nu$, $n_i$ e $n_j$. Três icógnitas e uma equação!

## Aproximação ETL

No equilíbrio termodinamico local (ETL), usamos que 

$$\dfrac{n_{j}}{n_{i}}=\dfrac{g_{j}}{g_{i}}e^{-h v / k T}$$

Se a temperatura é a mesma em toda região e $n(z) = n_i(z) + n_j(z)$ com $n(z)$ e $T$ dados ou fixos. Portanto, temos 3 equações e 3 incógnita: $I_\nu(z,\mu)$,  $n_i(z)$, $n_j(z)$. Desta forma, a solução desses 3 equações simultaneamente fornece a estrutura da atmosfera: campo de radiação + estado do gás.

Mas podemos ter T(z) e não conhecer $n(z)$. Como proceder?

$n(z)$: que tal equilíbrio hidrostático? $- \nabla p = - \dfrac{GM\rho}{z^2} \hat{r}$; $\rho \longleftrightarrow n(z)$, aparece $P(z)$.

$P(z)$: que tal usar a equação de estado? $f(P,N,T) = 0$; $P = NkT$.

Com isso podemos igualar o número de equações com o número de incógnitas, porem não temos $T(z)$. Temos que usar transporte energia (equilíbio radiativo).

Ou seja:

- equação de transporte;
- equação de Boltzmann (ETL);
- equilíbrio hidrostático (P, S);
- equilíbrio radiativo (T);
- equação de estado.

Solução nos dá: $I_\nu(z,\mu)$, $n_i(z)$, $n_j(z)$, $P(z)$, $T(z)$.

Lembrando que ETL pode funcionar muito bem ou falhar miseravelmente! Se falhar, tentar caso não-ETL! (equações de equilíbrio estatístico para $n_i$ e $n_j$.

A complexidade cresce como:

- E.T. (gás + radiação conhecidos)
- E.T.L. (gás conhecido)
- não-E.T.L. (nada conhecido)

# Teoria básica de campos radiativos

Equações de Maxwell no cgs

$\nabla\cdot \vec{E}=4 \pi \rho$

$\nabla \cdot \vec{B}=0$

$\nabla \times \vec{E}=-\dfrac{\partial \vec{B}}{\partial t} \dfrac{1}{c}$

$\nabla \times \vec{B}=\dfrac{4 \pi}{c} \vec{j}+\dfrac{1}{c} \dfrac{\partial \vec{E}}{\partial t}$

Força de Lorentz

$\vec{F}=q(\vec{E}+\vec{\nabla} \times \vec{B} / c)$

$\vec{f}=\rho(\vec{E}+\vec{v} \times \vec{B} / c)=\rho \vec{E}+\vec{j} \times \vec{B} / c \quad ; \vec{\jmath}=\rho \vec{v}$

Nessas equações

- conservação de carga, momento e energia
- invariância relativística
- contém: radiação eletromagnética

Exemplo: carga

$\nabla \cdot(\nabla \times \vec{B})=\nabla \cdot \dfrac{(4 \pi\vec{\jmath})}{c}+\dfrac{1}{c} \dfrac{\partial}{\partial t} \nabla \vec{E}=\dfrac{\nabla(4 \pi\vec{\jmath})}{c} +\dfrac{1}{c} \dfrac{\partial}{\partial t}(4\pi \rho)=0$

$\nabla \cdot \vec{j}+\dfrac{\partial \rho}{\partial z}=0$

## Teorema de Poynting

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2031.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2031.png)

Lorentz: $d\vec{F}=dq(\vec{E}+\vec{v} \times \vec{B}/c)$ 
por volume: $\vec{f} = \dfrac{d \vec{F}}{d V}=\rho \vec{E}+\rho \vec{v} \times \vec{B} / c$
$\vec{f}=\rho \vec{E}+\vec{j} \times \vec{B} / c$

Trabalho: $\dfrac{dW}{dV dt} = \dfrac{d\vec{F}}{dV}\cdot\dfrac{d\vec{s}}{dt} = \vec{f}\cdot\vec{v} = \rho\dfrac{d\vec{v}}{dt} \cdot \vec{v} = \rho \dfrac{1}{2} \dfrac{dv^2}{dt} = \dfrac{d}{dt}\left(\dfrac{1}{2} \rho v^2\right)$

No nosso problema: $\vec{f}\cdot\vec{v} = \rho\vec{v}\cdot\vec{E} + \cancel{\vec{v}\cdot(\underbrace{\rho\vec{v}\times\vec{B}}_{\perp\vec{v}})/c} = \rho\vec{v}\cdot\vec{E} = \vec{j}\cdot\vec{E}$

Então $\dfrac{d\,u_{mec}}{dt} = \vec{j}\cdot\vec{E}$; na equação de Ampère-Maxwell $\nabla\times\vec{B}=\vec{4\pi}{c}\vec{j} + \dfrac{1}{c}\dfrac{\partial \vec{E}}{\partial t}$

$\vec{j} = \dfrac{c}{4\pi}\nabla\times\vec{B} - \dfrac{1}{4\pi}\dfrac{\partial\vec{E}}{\partial t}$

$\vec{j}\cdot\vec{E} = \dfrac{c}{4\pi} \vec{E}\cdot(\nabla \times \vec{B}) - \dfrac{1}{4\pi}\vec{E}\cdot\dfrac{\partial\vec{E}}{\partial t} = \dfrac{c}{4\pi} \vec{E}\cdot(\nabla \times \vec{B})  - \dfrac{1}{4\pi}\dfrac{1}{2}\dfrac{\partial\vec{E}^2}{\partial t}\\
 = \dfrac{c}{4\pi} \vec{E}\cdot(\nabla \times \vec{B})  - \dfrac{\partial}{\partial t}\left(\dfrac{{E}^2}{8\pi}\right) = \dfrac{c}{4\pi} \vec{E}\cdot(\nabla \times \vec{B})  - \dfrac{\partial\, u_E}{\partial t}$

Utilizando outra equação

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2032.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2032.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2033.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2033.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2034.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2034.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2035.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2035.png)

## Ondas eletromagnéticas planas

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2036.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2036.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2037.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2037.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2038.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2038.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2039.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2039.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2040.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2040.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2041.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2041.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2042.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2042.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2043.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2043.png)

### Fluxo de energia de ondas planas

A variação total da energia de um sistema está associada a uma fuga de energia pela borda do sistema. Para ondas planas, $\vec{E}(\vec{r}, t) = \hat{a}_1E_0e^{i(\vec{k}\cdot\vec{r}) - \omega t}$ e  $\vec{B}(\vec{r}, t) = \hat{a}_2B_0e^{i(\vec{k}\cdot\vec{r}) - \omega t}$. Para calcularmos um vertor de Poynting mensurável, precisamos de

$$⁍$$

Devido às altas frequências da luz, é mais interesssante obter um valor médio para o vetor de Poynting. Ao realiza a média temporal, os termos com exponenciais somem, pois a média temporal de senos e cossenos é nula. 

$$⁍$$

## Espectro de radiação

As oscilações do campo são dadas pela frequência e não conseguimos obter informações sobre a frequência ao observer apenas um instante de tempo, precisamos esperar a "onda passar" por um tempo $\Delta t$ para termos informações sobre as frequências. Uma foto do campo pode ter qualquer frequência, pois não conseguimos acompanhar a evolução temporal das componentes do campo. Temos que $\Delta \omega \Delta \omega > 1$; se observamos por muito tempo, obtemos uma resolução alta.

Vamos considerar um pulso finito de radiação e acompanhar apenas a parte espacial do campo  ${\vec{E}.}$ Seja $E(t) = \hat{a}\cdot\vec{E}(t)$

Poynting: $S = \dfrac{W}{dA dt} = \dfrac{c}{4\pi} E^2(t)$

Temos: $\displaystyle\dfrac{dW}{dA} = \dfrac{c}{4\pi}\int\limits_{-\infty}^{+\infty} E^2(t) dt$ 

Usaremos Fourier daqui em diante:

- $\hat{E}(\omega) = \int\limits_{-\infty}^{+\infty} E(t)e^{i\omega t} dt$

- ${E}(t) =  \dfrac{1}{2\pi}\int\limits_{-\infty}^{+\infty} E(\omega)e^{-i\omega t} d\omega$
- $\hat{E}(\omega)^*\hat{E}(\omega) = \hat{E}(-\omega)\hat{E}(-\omega)^*$

$$\begin{aligned}
\displaystyle
\dfrac{dW}{dA} &= \dfrac{c}{4\pi}\int\limits_{-\infty}^{+\infty} E(t)  \int\limits_{-\infty}^{+\infty} \hat{E}(\omega)e^{-i\omega t} d\omega dt\\
& = \dfrac{c}{4\pi}\int\limits_{-\infty}^{+\infty} \hat{E}(\omega)\int\limits_{-\infty}^{+\infty}E(t) e^{-i\omega t} dt d\omega\\
& = \dfrac{c}{4\pi}\int\limits_{-\infty}^{+\infty} \hat{E}(\omega)2\pi\hat{E}(-\omega) d\omega\\
& = \dfrac{c}{2}\int\limits_{-\infty}^{+\infty} \hat{E}(\omega)\hat{E}^*(\omega) d\omega= \dfrac{c}{2}\int\limits_{-\infty}^{+\infty} |\hat{E}(\omega)|^2 d\omega\\
& = {c}\int\limits_{0}^{+\infty} |\hat{E}(\omega)|^2 d\omega\\
\end{aligned}$$

Portanto $\dfrac{dW}{dA d\omega} = \dfrac{erg}{cm^2\, Hz} = c |\hat{E}(\omega)|^2$

Espectro usual em astronomia: $\dfrac{erg}{cm^2\, Hz\, s}$. Podemos construir $\dfrac{dW}{dAd\omega\,dt} = \dfrac{1}{T}\dfrac{dW}{dA d\omega}$, onde T é o intervalo em que o pulso se repete.

Supondo que

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2044.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2044.png)

A informação vai depender de qual porção de tempo observamos.

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2045.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2045.png)

## Formulação potencial da eletrodinâmica

Vamos escrever as equações de Maxwell em função dos pontenciais ao invés dos campos. Para isso, usaremos o teorema da decomposição de Helmholtz.

> In physics and mathematics, in the area of vector calculus, Helmholtz's theorem,[1][2] also known as the fundamental theorem of vector calculus,[3][4][5][6][7][8][9] states that any sufficiently smooth, rapidly decaying vector field in three dimensions can be resolved into the sum of an irrotational (curl-free) vector field and a solenoidal (divergence-free) vector field; this is known as the Helmholtz decomposition or Helmholtz representation. It is named after Hermann von Helmholtz.[10]
As an irrotational vector field has a scalar potential and a solenoidal vector field has a vector potential, the Helmholtz decomposition states that a vector field (satisfying appropriate smoothness and decay conditions) can be decomposed as the sum of the form  ${\displaystyle -\nabla \phi +\nabla \times \mathbf {A} }$ , where ${\displaystyle \phi }$ is a scalar field called "scalar potential", and A is a vector field, called a vector potential.

Let ${\displaystyle \mathbf {F} }$ be a vector field on a bounded domain ${\displaystyle V\subseteq \mathbb {R} ^{3}}$ , which is twice continuously differentiable, and let ${\displaystyle S}$ be the surface that encloses the domain ${\displaystyle V}$ . Then ${\displaystyle \mathbf {F} }$ can be decomposed into a curl-free component and a divergence-free component:[11][12]
${\displaystyle \mathbf {F} =-\nabla \Phi +\nabla \times \mathbf {A}}$

Se $\gdef\v#1{\vec{#1}}
\nabla\cdot\v{B} = 0$ , podemos escrever $\gdef\v#1{\vec{#1}}\v{B} = \nabla\times\v{A}$, pois $\gdef\v#1{\vec{#1}}
\gdef\rot#1{\nabla\times\vec{#1}}
\gdef\di#1{\nabla\cdot\vec{#1}}
\nabla\cdot(\rot{A}) = 0$. Também usaremos que $\nabla\times\vec{f} = 0 \implies \vec{f} = -\nabla{a}$

Vamos começar pela equação de Faraday

$$\gdef\v#1{\vec{#1}}\gdef\rot#1{\nabla\times\vec{#1}}\gdef\di#1{\nabla\cdot\vec{#1}}
\begin{aligned}
\rot{E} &= -\dfrac{1}{c} \dfrac{\partial}{\partial t} \rot{A}\\
\nabla\times\left(\vec{E} + \dfrac{1}{c} \dfrac{\partial \vec{A}}{\partial t}\right) & = 0\\
\therefore\quad \vec{E} + \dfrac{1}{c} \dfrac{\partial \vec{A}}{\partial t} & = -\nabla\Phi
\end{aligned}
$$

Portanto

$$⁍$$

Na equação de Coulomb

$$\begin{aligned}
\nabla\cdot\vec{E} &= 4\pi\rho\\
\nabla\cdot\left(-\nabla\Phi - \dfrac{1}{c} \dfrac{\partial\vec{A}}{\partial t}\right)&= 4\pi\rho\\
-\nabla^2\Phi - \dfrac{1}{c} \dfrac{\partial(\nabla\cdot\vec{A})}{\partial t}&= 4\pi\rho\\
\end{aligned}$$

Na equação de Ampère-Maxwell

$$\begin{aligned}
\vec{B} &= \dfrac{4\pi}{c} \vec{j} + \dfrac{1}{c}\dfrac{\partial \vec{E}}{\partial t}\\
\nabla\times(\nabla\times\vec{A}) & = \dfrac{4\pi}{c} \vec{j} + \dfrac{1}{c}\dfrac{\partial}{\partial t}\left(-\nabla\Phi - \dfrac{1}{c} \dfrac{\partial\vec{A}}{\partial t}\right)\\
-\nabla^2\vec{A} + \nabla(\nabla\cdot\vec{A}) & = \dfrac{4\pi}{c} \vec{j} + \dfrac{1}{c}\dfrac{\partial}{\partial t}\left(-\nabla\Phi - \dfrac{1}{c} \dfrac{\partial\vec{A}}{\partial t}\right)
\end{aligned}$$

Os dois resultados anteriores estão acoplados e não são simples de resolver. Na tentativa de simplificar a resolução, vamos empregar uma transformação de calibre.

## Transformação de calibre

Uma transformação de calibre é uma transformação contínua em relação ao espaço e ao tempo. $\vec{A}$ e $\Phi$ não estão unicamente definidos e altera-los não afeta os campos. Para provar isso, vamos supor uma função de calibre $\lambda$, tal que 

- Se $\vec{B} = \nabla\times\vec{A}$, temos a liberdade de escolher $\vec{A'} = \vec{A} + \nabla\lambda$ contanto que $\lambda$ satisfaça

    $$\vec{B'} = \nabla\times\vec{A} + \underbrace{\nabla\times(\nabla\lambda)}_{=0} = \vec{B}$$

- E do campo elétrico temos que $\vec{E'} = -\nabla\Phi' - \dfrac{1}{c} \dfrac{\partial\vec{A'}}{\partial t}$, portanto

$$⁍$$

somos obrigados a considerar ${\Phi' = \Phi - \dfrac{1}{c}\dfrac{\partial\lambda}{\partial t}}$ para manter o campo inalterado.

Dito isso, temos a liberdade de escolher a função $\lambda$, ou seja, de escolher o calibre no qual resolveremos as contas. Essa liberdade é chamada de escolha de calibre e nos permite modificar $(\Phi, \vec{A})$ sem alterar os campos $(\vec{E},\vec{B})$. A ideia para resolver as equações acopladas que encontramos antes, é escolher uma função de calibre que facilite as contas.

## Calibre de Lorenz

Agora podemos prosseguir no desenvolvimento ao escolher um calibre para as equações

$$\begin{cases}
\nabla^2\Phi - \dfrac{1}{c} \dfrac{\partial(\nabla\cdot\vec{A})}{\partial t}= 4\pi\rho\\
-\nabla^2\vec{A} + \nabla(\nabla\cdot\vec{A}) = \dfrac{4\pi}{c} \vec{j} + \dfrac{1}{c}\dfrac{\partial}{\partial t}\left(-\nabla\Phi - \dfrac{1}{c} \dfrac{\partial\vec{A}}{\partial t}\right)
\end{cases}$$

Vamos usar o calibre de Lorentz, $\nabla\cdot\vec{A} = - \dfrac{1}{c}\dfrac{\partial\Phi}{\partial t}$. As equações se tornarão simétricas

$$\begin{cases}
- \nabla^2\Phi + \dfrac{1}{c^2} \dfrac{\partial^2 \Phi}{\partial t^2}= 4\pi\rho\\
-\nabla^2\vec{A} +  \dfrac{1}{c^2} \dfrac{\partial^2 \vec{A}}{\partial t^2} = \dfrac{4\pi}{c} \vec{j}
\end{cases}
\begin{cases}
\Box^2\Phi= -4\pi\rho\\
\Box^2\vec{A} = -{4\pi}\vec{j}/c
\end{cases}$$

Se $\nabla\cdot\vec{A} + \dfrac{1}{c}\dfrac{\partial \Phi}{\partial t} = f$, podemos pensar em outro $\vec{A'}$ e $\Phi'$ onde ${\nabla\cdot\vec{A'} + \dfrac{1}{c}\dfrac{\partial \Phi'}{\partial t} = 0}$ fazendo

$\begin{cases}
\vec{A'} = \vec{A} + \nabla\lambda\\
\Phi' = \Phi - \dfrac{1}{c}\dfrac{\partial\lambda}{\partial t}
\end{cases}$

$\nabla\cdot(\vec{A} + \nabla\lambda) + \dfrac{1}{c}\dfrac{\partial}{\partial t} \left(\Phi - \dfrac{1}{c}\dfrac{\partial\lambda}{\partial t}\right) = 0\\
\underbrace{\nabla\cdot\vec{A} + \dfrac{1}{c}\dfrac{\partial\Phi}{\partial t}}_{f}  + \nabla^2\lambda  - \dfrac{1}{c^2}\dfrac{\partial^2\lambda}{\partial t^2} = 0\\$

Então, basta que $\nabla^2\lambda - \dfrac{1}{c^2}\dfrac{\partial^2\lambda}{\partial t^2} = -f$ seja considerada e o $\lambda$ correspondete fornecerá o calibre de Lorenz.

## Resolução via função de Green

Podemos resolver problemas diferenciais parciais transformando-os em um problema de Green. Começando pela equação para o potencial e obtendo o problema de Green correspondente:

$$\Box^2\underbrace{\Phi(\vec{r}, t)}_{G(\vec{r}-\vec{r'}, t - t')}= -4\pi\underbrace{\rho(\vec{r},t)}_{\delta^3(\vec{r}-\vec{r'})\delta(t-t')}$$

Para resolver usaremos o método da transformada de Fourier. Precisamos saber que:

- ${f}(\omega) = \int\limits_{-\infty}^{+\infty} f(t)e^{i\omega t} dt$
- $\delta(t-t') = \dfrac{1}{2\pi}\int\limits^{\infty}_{-\infty} e^{-i\omega(t-t')}$

- ${f}(t) =  \dfrac{1}{2\pi}\int\limits_{-\infty}^{+\infty} f(\omega)e^{-i\omega t} d\omega$

Escrevendo a função de Green como

$$⁍$$

Agora podemos passar todo o problema para o espaço de Fourier

$$\Box^2 G(\vec{r}-\vec{r'}, t - t') = -4\pi\delta^3(\vec{r}-\vec{r'})\delta(t-t')
\\
\left(\nabla^2 -\dfrac{1}{c^2}\dfrac{\partial^2}{\partial t^2}\right)\dfrac{1}{2\pi}\int\limits_{-\infty}^{+\infty} G(r-r',\omega)e^{-i\omega (t-t')} d\omega \\= -4\pi\delta^3(\vec{r}-\vec{r'})\dfrac{1}{2\pi}\int\limits^{\infty}_{-\infty} e^{-i\omega(t-t')} d\omega
\\
\int\limits_{-\infty}^{+\infty} e^{-i\omega (t-t')}\nabla^2G(r-r',\omega)d\omega - \dfrac{1}{c^2}\int\limits_{-\infty}^{+\infty} (-\omega^2)G(r-r',\omega)e^{-i\omega (t-t')} = -4\pi\delta^3(\vec{r}-\vec{r'})\int\limits^{\infty}_{-\infty} e^{-i\omega(t-t')} d\omega$$

$$\int\limits_{-\infty}^{\infty} d\omega e^{-i\omega}\left\{ \nabla^2G(R,\omega) + \dfrac{\omega^2}{c^2} G(R,\omega) + 4\pi\delta^3(R)\right\} = 0
\\
\therefore\quad \nabla^2G(R,\omega) + \dfrac{\omega^2}{c^2} G(R,\omega) + 4\pi\delta^3(R) = 0$$

Portanto, o que precisamos resolver é

$$\nabla^2G(R,\omega) +  k^2G(R,\omega) = - 4\pi\delta^3(R);\;k=\dfrac{\omega}{c}$$

Para $R > 0$

$$\begin{aligned}
\nabla^2G(R,\omega) + k^2G(R,\omega) = 0
\\
\dfrac{1}{R}\dfrac{d^2[RG(R,\omega)]}{dR^2} + k^2G(R,\omega) = 0
\\
[RG(R,\omega)]" + k^2[RG(R,\omega)] = 0
\end{aligned}$$

E procuramos uma solução do tipo $RG(R,\omega) = ce^{\pm i k R}$, de forma que

$$G(R,\omega) = \dfrac{ce^{\pm i k R}}{R}$$

Análise do comportamento em $R \to 0$. 

A equação original é ${\nabla^2G(R,\omega) + k^2G(R,\omega) = -4\pi\delta^3(R)}$. Integrando em uma esfera $\Omega$

$$\int_\Omega\nabla^2G(R,\omega)\,d^3R + k^2\int_\Omega G(R,\omega)\,d^3R=-4\pi\int_\Omega \delta^3(R)\,d^3R$$

Considerando essa esfera como infinitesimal ($\Omega\to0)$

$$\int_\Omega\nabla^2G(R,\omega)\,d^3R + k^2\int_\Omega \dfrac{ce^{\pm i k R}}{R}\,d^3R=-4\pi
\\
\int_\Omega\nabla^2G(R,\omega)\,dR^3 + k^2\int\oint \underbrace{\dfrac{ce^{\pm i k R}}{\cancel{R}}R^{\cancel{2}}}_{\to 0}\,dR\,d\Omega=-4\pi
\\
\int_\Omega\nabla\cdot(\nabla G(R,\omega)\,dR^3 =-4\pi
\\
\oint_{\partial\Omega}\nabla G(R,\omega)\cdot\hat{n}\,dA =-4\pi
\\
\oint_{\partial\Omega}\nabla G(R,\omega)\cdot\hat{n}\,dA =-4\pi
\\
\oint_{\partial\Omega}\dfrac{d\, G(R,\omega)}{dR}dA =-4\pi
\\
\dfrac{d\, G(R,\omega)}{dR}R^2\oint_{\partial\Omega}d\Omega =-4\pi
\\
\dfrac{d\, G(R,\omega)}{dR}R^2 = -1$$

Com isso podemos calular $c$

$$\dfrac{d\, G(R,\omega)}{dR}R^2 = -1
\\
\left(-\dfrac{c}{R^2}e^{\pm i k R} + \dfrac{c}{R}(\pm ik)e^{\pm i k R}\right)R^2 = -1
\\
-ce^{\pm i k R} + {c}{R}(\pm ik)e^{\pm i k R} = -1
\\
\lim\limits_{R\to 0} \left\{-ce^{\pm i k R} + {c}{R}(\pm ik)e^{\pm i k R} = -1\right\}\\
-c + 0 = -1\\
c = 1
$$

Finalmente, $G(R,\omega) = \dfrac{e^{\pm i k R}}{R}$ e:

$$\begin{aligned}
G(r - r', t-t') &= \dfrac{1}{2\pi}\int\limits_{-\infty}^{\infty} G(R,\omega) e^{-i\omega(t-t')}\, d\omega
\\
 &= \dfrac{1}{2\pi R}\int\limits_{-\infty}^{\infty} {e^{\pm i k R-i\omega(t-t')}}\, d\omega
\\
 &= \dfrac{1}{2\pi R}\int\limits_{-\infty}^{\infty} {e^{-i\omega[t-(t'\mp R/c)]}}\, d\omega\\
\end{aligned}$$

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2046.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2046.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2047.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2047.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2048.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2048.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2049.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2049.png)

## Potenciais de Liérnad-Wiechert

Vimos que

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2050.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2050.png)

$$⁍$$

Seja: $\vec{r}_0 = \text{trajetória do $e^-$}$ e $\dot{\vec{r}} = \vec{u} = \text{velocidade}$

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2051.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2051.png)

Carga pontual:

$\begin{cases}
\rho(\vec{r}, t) = q\delta^3(\vec{r} - \vec{r}_0(t))\\
\vec{j}(\vec{r},t) = q\vec{u}\delta^3(\vec{r} - \vec{r}_0(t))
\end{cases}$

- $t_R = t-\dfrac{|\vec{r} - \vec{r}_0|}{c}$

- $\vec{R} = \vec{r} - \vec{r}_0(t') = \vec{R}(t')$

- $|\vec{R}| = |\vec{r} - \vec{r}_0(t')|$

- $\int f(x) \delta (x-a) dx = f(a)$

Para $\Phi$:

$$\begin{aligned}
\Phi(\vec{r},t) &= \int\int\dfrac{dt'\rho(\vec{r'}, t)\delta(t'-t_R)}{|\vec{r}-\vec{r'}|}d^3{r'}\\
& = \int\dfrac{dt'q\delta^3(\vec{r} - \vec{r}_0(t))\delta(t'-t_R)}{|\vec{r}-\vec{r'}|}d^3{r'}
\\
& = q\int\dfrac{dt'\delta[t'- t + |\vec{r}-\vec{r}_0(t')|/c]}{|\vec{r}-\vec{r'}|}d^3{r'}
\\
& = q\int\dfrac{dt'}{R(t')}{\delta[t'- t + R(t')/c]}
\end{aligned}$$

Seja $t''=t'-t+R(t')/c$, $dt'' = dt'+\dfrac{1}{c}\dfrac{dR}{dt'} = dt'\left(1+\dfrac{\dot{R}}{c}\right)$

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2052.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2052.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2053.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2053.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2054.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2054.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2055.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2055.png)

## Campos assintóticos

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2056.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2056.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2057.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2057.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2058.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2058.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2059.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2059.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2060.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2060.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2061.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2061.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2062.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2062.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2063.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2063.png)

### Distribuição da potência irradiada

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2064.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2064.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2065.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2065.png)

### Carga acelerada não-relativística

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2066.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2066.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2067.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2067.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2068.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2068.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2069.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2069.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2070.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2070.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2071.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2071.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2072.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2072.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2073.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2073.png)

## Aproximação dipolar de um sistema de partículas

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2074.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2074.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2075.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2075.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2076.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2076.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2077.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2077.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2078.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2078.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2079.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2079.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2080.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2080.png)

## Espalhamento Thomson

O espalhamento Thomson é o espalhamento da radiação por cargas livres. 

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2081.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2081.png)

$\vec{E}=\hat{\epsilon}E_0\sin\omega_0 t$

$\vec{F} = e\vec{E} = \hat{\epsilon}eE_0\sin\omega_0 t = m\ddot{\vec{r}}$

(i) $\vec{E}(maxwell) = \vec{E}_v + \vec{E}_{rad} = \vec{E}_{rad} \overset{N.R.}{=} \left[\dfrac{q}{c}\dfrac{\hat{n}\times(\hat{n}\times\dot{\vec{B}})}{R}\right]_{t_R}$e ${\dfrac{dP}{d\Omega} = R^2S = R^2\dfrac{c}{4\pi}E^2_{rad}}$

(ii) Dipolo: $\vec{d}=e\vec{r}$ e $\dfrac{dP}{d\Omega} = \dfrac{\ddot{d}\sin^2\theta}{4\pi c^3}$

(iii) Campos assintóticos $\dfrac{dP}{d\Omega}=\dfrac{1}{4\pi c^3}\left|\hat{n}\times\int d^3r' \dot{\vec{j}}(\vec{r'}, t_R)\right|^2$;

 $t_R = t - \dfrac{r}{c} + \dfrac{\hat{n}\cdot\vec{r}_0(t_R)}{c} \approx t - r/c$

(i) Campo  $\vec{E}_{rad}$

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2082.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2082.png)

$\vec{E}_{rad} = \left[\dfrac{q}{c}\dfrac{\hat{n}\times(\hat{n}\times\dot{\vec{\beta}})}{R}\right]_{t_R}$; $\dot{\vec{\beta}} = \dfrac{\vec{a}}{c} = \ddot{\vec{r}} {c}$

a dinâmica: $\ddot{\vec{r}} = \hat{\epsilon}eE_0\sin\omega_0 t /m$

$\vec{E}_{rad} = \left[\dfrac{e}{c^2}\dfrac{\hat{n}\times(\hat{n}\times\ddot{\vec{r}})}{R}\right]{t_R}\implies\vec{E}_{rad} = \dfrac{e^2 E_0 \sin\omega t \sin\theta}{mc^2R}$

Vetor Poynting: $\dfrac{}{}$$S = \dfrac{dP}{dA} = \dfrac{dP}{R^2 d\Omega} \implies \dfrac{dP}{d\Omega} = \dfrac{R^2c}{4\pi} E^2_{rad}$

$\dfrac{dP}{d\Omega} = \dfrac{\cancel{R^2}c}{4\pi}\dfrac{e^4 E^2_0 \sin^2\omega_0 t \sin^2\theta}{m^2c^4\cancel{R^2}} = \dfrac{e^4 E^2_0 \sin^2\omega_0 t \sin^2\theta}{{4\pi} m^2c^3}$

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2083.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2083.png)

$<dP/d\Omega> =  \dfrac{e^4 E^2_0 \sin^2\theta}{{8\pi} m^2c^3}$

Padrão de emissão de radiação do elétron após incidência da onda plana.

$P = \int\dfrac{dP}{d\Omega}d\Omega = \dfrac{e^4 E_0^2}{3m^2c^3}$

(ii) Dipolo/radiação

Vimos que: $\dfrac{dP}{d\Omega} = \dfrac{\ddot{d}^2\sin^2\theta}{4\pi c^3}$

No nosso caso $\vec{d} = e\vec{r}$; $\ddot{\vec{d}} = e\ddot{\vec{r}} = e\dfrac{\vec{F}_e}{m}$

$\ddot{d} = e^2 E_0 \sin\omega_0 t / m$; 

$\dfrac{dP}{d\Omega} = \dfrac{e^4 E^2_0 \sin^2\omega_0 t \sin^2\theta}{{4\pi} m^2c^3}$; $<dP/d\Omega> = \dfrac{e^4 E^2_0 \sin^2\theta}{{8\pi} m^2c^3}$; $P = \dfrac{e^4 E_0^2}{3m^2c^3}$

(iii) Campos assintóticos

$\dfrac{dP}{d\Omega}=\dfrac{1}{4\pi c^3}\left|\hat{n}\times\int d^3r' \dot{\vec{j}}(\vec{r'}, t_R)\right|^2$

No nosso sistema

$\vec{j}(\vec{r},t) = e\dot{\vec{r}}_0 \delta^3(\vec{r}-\vec{r}_0(t))$; $\dot{\vec{j}}(\vec{r},t) = e\ddot{\vec{r}}_0 \delta^3(\vec{r}-\vec{r}_0(t))=\dfrac{e^2}{m} E_0 \sin\omega t\delta^3(\vec{r} - \vec{r}_0(t))\hat{\epsilon}$

$\dfrac{dP}{d\Omega}=\dfrac{1}{4\pi c^3}\left|\hat{n}\times\int d^3r' \dot{\vec{j}}(\vec{r'}, t_R)\right|^2=\dfrac{1}{4\pi c^3}\left|\hat{n}\times\int d^3r' \dfrac{e^2}{m} E_0 \sin\omega t\delta^3(\vec{r} - \vec{r}_0(t))\hat{\epsilon}\right|^2$

mas $t_R = t - \dfrac{r}{c} + \hat{n}\cdot\dfrac{\vec{r}_0(t_R)}{c}$

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2084.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2084.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2085.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2085.png)

![Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2086.png](Processos%20Radiativos%202f22edc3a22b46a5be939d4977fe81ea/Untitled%2086.png)